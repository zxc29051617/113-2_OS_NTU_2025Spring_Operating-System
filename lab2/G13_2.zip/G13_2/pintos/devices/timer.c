#include "devices/timer.h"
#include <debug.h>
#include <inttypes.h>
#include <round.h>
#include <stdio.h>
// ------------------------------------------------------------------------------------- lab2 start
#include <stdarg.h>
// ------------------------------------------------------------------------------------- lab2 end
#include "devices/pit.h"
#include "threads/interrupt.h"
#include "threads/synch.h"
#include "threads/thread.h"
  
/* See [8254] for hardware details of the 8254 timer chip. */

#if TIMER_FREQ < 19
#error 8254 timer requires TIMER_FREQ >= 19
#endif
#if TIMER_FREQ > 1000
#error TIMER_FREQ <= 1000 recommended
#endif

/* Number of timer ticks since OS booted. */
static int64_t ticks;

/* Number of loops per timer tick.
   Initialized by timer_calibrate(). */
static unsigned loops_per_tick;

// ------------------------------------------------------------------------------------- lab2 start
static struct list sleeping_threads;
// ------------------------------------------------------------------------------------- lab2 end

static intr_handler_func timer_interrupt;
static bool too_many_loops (unsigned loops);
static void busy_wait (int64_t loops);
static void real_time_sleep (int64_t num, int32_t denom);
static void real_time_delay (int64_t num, int32_t denom);

/* Sets up the timer to interrupt TIMER_FREQ times per second,
   and registers the corresponding interrupt. */
void
timer_init (void) 
{
  pit_configure_channel (0, 2, TIMER_FREQ);
  intr_register_ext (0x20, timer_interrupt, "8254 Timer");
  // ------------------------------------------------------------------------------------- lab2 start
  list_init(&sleeping_threads);
  // ------------------------------------------------------------------------------------- lab2 end
}

/* Calibrates loops_per_tick, used to implement brief delays. */
void
timer_calibrate (void) 
{
  unsigned high_bit, test_bit;

  ASSERT (intr_get_level () == INTR_ON);
  printf ("Calibrating timer...  ");

  /* Approximate loops_per_tick as the largest power-of-two
     still less than one timer tick. */
  loops_per_tick = 1u << 10;
  while (!too_many_loops (loops_per_tick << 1)) 
    {
      loops_per_tick <<= 1;
      ASSERT (loops_per_tick != 0);
    }

  /* Refine the next 8 bits of loops_per_tick. */
  high_bit = loops_per_tick;
  for (test_bit = high_bit >> 1; test_bit != high_bit >> 10; test_bit >>= 1)
    if (!too_many_loops (loops_per_tick | test_bit))
      loops_per_tick |= test_bit;

  printf ("%'"PRIu64" loops/s.\n", (uint64_t) loops_per_tick * TIMER_FREQ);
}

/* Returns the number of timer ticks since the OS booted. */
int64_t
timer_ticks (void) 
{
  enum intr_level old_level = intr_disable ();
  int64_t t = ticks;
  intr_set_level (old_level);
  return t;
}

/* Returns the number of timer ticks elapsed since THEN, which
   should be a value once returned by timer_ticks(). */
int64_t
timer_elapsed (int64_t then) 
{
  return timer_ticks () - then;
}

/* Sleeps for approximately TICKS timer ticks.  Interrupts must
   be turned on. */
// ------------------------------------------------------------------------------------- lab2 start
void
timer_sleep (int64_t ticks) 
{
  // If ticks is non-positive, do nothing.
  if (ticks <= 0) {
      return;
  }

  struct thread *cur = thread_current ();
  enum intr_level old_level;

  // 計算喚醒時間
  int64_t wakeup_time = timer_ticks () + ticks; 
  
  // 設置執行緒的喚醒時間
  cur->wakeup_time = wakeup_time;

  ASSERT (intr_get_level () == INTR_ON); 

  old_level = intr_disable ();
  list_insert_ordered(&sleeping_threads, &cur->elem, compare_time, 0);
  thread_block();

  intr_set_level (old_level);
}
// ------------------------------------------------------------------------------------- lab2 end

/* Sleeps for approximately MS milliseconds.  Interrupts must be
   turned on. */
void
timer_msleep (int64_t ms) 
{
  real_time_sleep (ms, 1000);
}

/* Sleeps for approximately US microseconds.  Interrupts must be
   turned on. */
void
timer_usleep (int64_t us) 
{
  real_time_sleep (us, 1000 * 1000);
}

/* Sleeps for approximately NS nanoseconds.  Interrupts must be
   turned on. */
void
timer_nsleep (int64_t ns) 
{
  real_time_sleep (ns, 1000 * 1000 * 1000);
}

/* Busy-waits for approximately MS milliseconds.  Interrupts need
   not be turned on.

   Busy waiting wastes CPU cycles, and busy waiting with
   interrupts off for the interval between timer ticks or longer
   will cause timer ticks to be lost.  Thus, use timer_msleep()
   instead if interrupts are enabled. */
void
timer_mdelay (int64_t ms) 
{
  real_time_delay (ms, 1000);
}

/* Sleeps for approximately US microseconds.  Interrupts need not
   be turned on.

   Busy waiting wastes CPU cycles, and busy waiting with
   interrupts off for the interval between timer ticks or longer
   will cause timer ticks to be lost.  Thus, use timer_usleep()
   instead if interrupts are enabled. */
void
timer_udelay (int64_t us) 
{
  real_time_delay (us, 1000 * 1000);
}

/* Sleeps execution for approximately NS nanoseconds.  Interrupts
   need not be turned on.

   Busy waiting wastes CPU cycles, and busy waiting with
   interrupts off for the interval between timer ticks or longer
   will cause timer ticks to be lost.  Thus, use timer_nsleep()
   instead if interrupts are enabled.*/
void
timer_ndelay (int64_t ns) 
{
  real_time_delay (ns, 1000 * 1000 * 1000);
}

/* Prints timer statistics. */
void
timer_print_stats (void) 
{
  printf ("Timer: %"PRId64" ticks\n", timer_ticks ());
}

// ------------------------------------------------------------------------------------- lab2 start
/*
在每個 timer interrupt 中:
1. 增加 ticks 計數器
2. 增加當前 process 的 recent_cpu
3. 每秒更新更新平均系統平均附載量 load_avg、每個 process 的 recent_cpu
4. 每4個時鐘週期更新所有 threads 的優先級
 */
static void
timer_interrupt (struct intr_frame *args UNUSED)
{
  ticks++;
  // 喚醒 sleep list 最前面的 thread
  wakeup_thread();
  
  if (thread_mlfqs) {
    /* 增加當前執行緒的recent_cpu */
    all_thread_increment_recent_cpu();
    
    /* 每個 timer 週期更新load_avg和所有執行緒的recent_cpu */
    if (ticks % TIMER_FREQ == 0) {
       all_thread_recalculate_load_avg();
       all_thread_recalculate_recent_cpu();
       
       // 確保所有執行緒優先級立即更新
       all_thread_recalculate_priorities();
    }
    
    /* 每4個時鐘週期更新所有執行緒的優先級 */
    else if (ticks % 4 == 0) {
      all_thread_recalculate_priorities();
    }
  }
  
  thread_tick ();
}
// ------------------------------------------------------------------------------------- lab2 end

/* Returns true if LOOPS iterations waits for more than one timer
   tick, otherwise false. */
static bool
too_many_loops (unsigned loops) 
{
  /* Wait for a timer tick. */
  int64_t start = ticks;
  while (ticks == start)
    barrier ();

  /* Run LOOPS loops. */
  start = ticks;
  busy_wait (loops);

  /* If the tick count changed, we iterated too long. */
  barrier ();
  return start != ticks;
}

/* Iterates through a simple loop LOOPS times, for implementing
   brief delays.

   Marked NO_INLINE because code alignment can significantly
   affect timings, so that if this function was inlined
   differently in different places the results would be difficult
   to predict. */
static void
busy_wait (int64_t loops) 
{
  while (loops-- > 0)
    barrier ();
}

/* Sleep for approximately NUM/DENOM seconds. */
static void
real_time_sleep (int64_t num, int32_t denom) 
{
  /* Convert NUM/DENOM seconds into timer ticks, rounding down.
          
        (NUM / DENOM) s          
     ---------------------- = NUM * TIMER_FREQ / DENOM ticks. 
     1 s / TIMER_FREQ ticks
  */
  int64_t ticks = num * TIMER_FREQ / denom;

  ASSERT (intr_get_level () == INTR_ON);
  if (ticks > 0)
    {
      /* We're waiting for at least one full timer tick.  Use
         timer_sleep() because it will yield the CPU to other
         processes. */                
      timer_sleep (ticks); 
    }
  else 
    {
      /* Otherwise, use a busy-wait loop for more accurate
         sub-tick timing. */
      real_time_delay (num, denom); 
    }
}

/* Busy-wait for approximately NUM/DENOM seconds. */
static void
real_time_delay (int64_t num, int32_t denom)
{
  /* Scale the numerator and denominator down by 1000 to avoid
     the possibility of overflow. */
  ASSERT (denom % 1000 == 0);
  busy_wait (loops_per_tick * num / 1000 * TIMER_FREQ / (denom / 1000)); 
}

// ------------------------------------------------------------------------------------- lab2 start
// 比較兩個 thread 的 wakeup_time 和 priority
// 如果兩個 thread 的 wakeup_time 相同，則比較 priority
// 如果 t1 的 wakeup_time 比 t2 小，則 t1 排在前面
// 如果 t1 和 t2 的 wakeup_time 相同，則比較 priority
// 如果 t1 的 priority 比 t2 大，則 t1 排在前面
// 否則 t2 排在前面
bool compare_time(struct list_elem *l1, struct list_elem *l2, void *aux UNUSED)
{
  const struct thread *t1 = list_entry(l1, struct thread, elem);
  const struct thread *t2 = list_entry(l2, struct thread, elem);

  // 先比較喚醒時間 (越早喚醒越優先)
  if (t1->wakeup_time < t2->wakeup_time)
    return true;
  
  // 若喚醒時間相同，則比較優先級 (優先級越高越優先)
  if (t1->wakeup_time == t2->wakeup_time && t1->priority > t2->priority)
    return true;
  
  // 其他情況
  return false;
}


/* 喚醒睡眠中的執行緒

 */
void wakeup_thread() {
  while (true) {
    // 如果睡眠列表為空，直接返回
    if (list_empty(&sleeping_threads))
      return;

    // 獲取睡眠列表中的第一個執行緒
    struct list_elem *top_elem = list_front(&sleeping_threads);
    struct thread *top_thread = list_entry(top_elem, struct thread, elem);

    // 檢查當前時間是否已經到達該執行緒的喚醒時間
    if (top_thread->wakeup_time <= ticks) {
      // 從睡眠列表中移除該執行緒
      list_pop_front(&sleeping_threads);
      // 解除執行緒的阻塞狀態
      thread_unblock(top_thread);
    }
    else {
      // 如果當前時間未到達喚醒時間，直接返回
      return;
    }
  }
}
// ------------------------------------------------------------------------------------- lab2 end
